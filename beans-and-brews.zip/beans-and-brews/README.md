# Beans and Brews
**Smart Coffee. Smarter Insights.**

A full-stack smart coffee vending management platform for offices — real-time machine
monitoring, consumption analytics, inventory intelligence, refill prediction, and
maintenance alerting, built on Spring Boot + MySQL + React.

Current architecture (MQTT intentionally **not** implemented yet — see below):

```
Coffee Machine Simulator → REST API → Spring Boot → Event Processing → MySQL → REST APIs → React
```

---

## 1. Features

- JWT authentication with role-based access (ADMIN / MANAGER / OPERATOR)
- Centralized dashboard: machine status, cups today, popular coffee, refill needs, active alerts
- Machine network view + detailed per-machine monitoring page
- Interactive office floor map with clickable machine markers grouped by department zone
- Interactive animated coffee machine simulator (brew/steam/dispense animation) with
  manual fault injection (low water/milk/coffee, high temperature, heater failure,
  machine failure, network disconnection, offline, restore) and a "Start Demo Mode"
  that auto-generates realistic office activity every 15 seconds
- Consumption analytics (daily/weekly/monthly trend, by department, recent activity)
- Coffee preference analysis (distribution, most/least popular, department breakdown)
- Peak usage hour detection computed from real stored data
- Inventory monitoring with visual gauges for water/milk/coffee powder
- Refill prediction: `estimated days = remaining inventory ÷ average daily consumption`
- Maintenance alerts with severity levels and acknowledge/resolve workflow
- Machine downtime tracking (offline duration, failure counts)
- Admin-only user management
- No emojis anywhere in the UI — Lucide icons + a coffee-inspired colour system throughout

---

## 2. Technology Stack

**Backend:** Java, Spring Boot 3, Spring Data JPA, Spring Security, JWT (jjwt), MySQL 8, Maven
**Frontend:** React 18, Vite, Axios, React Router, Recharts, Framer Motion, Lucide React

> Note on Java version: the project targets Java 21 in `pom.xml` for the widest Spring
> Boot 3.3.x compatibility. If you have JDK 25 installed, it will still run this
> project fine (JVMs are backward compatible) — Eclipse will just compile down to the
> configured `java.version`. You can bump `<java.version>` in `pom.xml` if you'd
> rather compile against 25 directly once your Spring Boot version officially supports it.

---

## 3. Project Structure

```
beans-and-brews/
├── backend/            Spring Boot app (com.beanbrew)
│   ├── pom.xml
│   └── src/main/java/com/beanbrew/
│       ├── config/       Security, CORS, scheduler, data seeder
│       ├── controller/    REST controllers
│       ├── dto/           Request/response objects
│       ├── entity/        JPA entities + enums
│       ├── repository/    Spring Data repositories
│       ├── security/      JWT util + filter
│       ├── service/       Business logic
│       ├── analytics/     Analytics aggregation service
│       ├── simulator/     Realistic consumption/behaviour engine
│       └── exception/     Global exception handling
├── frontend/           React + Vite app
│   └── src/
│       ├── api/           Axios client + endpoint modules
│       ├── components/    Reusable UI (Sidebar, MachineCard, CoffeeMachine, etc.)
│       ├── context/       Auth context
│       ├── hooks/         usePolling (real-time-like updates without WebSockets)
│       ├── pages/         Route-level pages
│       └── styles/        Design system CSS (coffee palette, typography)
├── database/
│   └── seed.sql        Reference schema (auto-created by Hibernate; not required to run)
├── .env.example
└── README.md
```

---

## 4. Database Setup

1. Install and start MySQL 8.
2. No manual schema creation needed — the backend auto-creates the `bean_brew`
   database and all tables on first run (`createDatabaseIfNotExist=true`,
   `spring.jpa.hibernate.ddl-auto=update`). `database/seed.sql` is provided purely
   as a readable reference of the schema.
3. Default credentials assumed: `root` / `root`. Override via environment variables
   or directly in `application.properties` (see below).

---

## 5. Backend Setup (Eclipse)

1. Import `backend/` into Eclipse as an **Existing Maven Project**.
2. Set environment variables (or edit `application.properties` directly):
   ```
   DB_USERNAME=root
   DB_PASSWORD=root
   JWT_SECRET=<any-long-random-string>
   CORS_ORIGINS=http://localhost:5173
   ```
3. Right-click `BeansAndBrewsApplication.java` → **Run As → Java Application**.
4. On first boot, the app seeds:
   - 3 demo users (admin, manager, operator)
   - 6 machines across 4 offices
   - ~10 days of realistic historical consumption (so charts/predictions aren't empty)
5. Backend runs at `http://localhost:8080`.

---

## 6. Frontend Setup (VS Code)

```bash
cd frontend
npm install
copy .env.example .env      (Windows)  /  cp .env.example .env   (macOS/Linux)
npm run dev
```

Frontend runs at `http://localhost:5173` and proxies `/api` calls to the backend.

---

## 7. Demo Credentials

| Role     | Email                          | Password       |
|----------|--------------------------------|----------------|
| Admin    | admin@beansandbrews.com        | Admin@123      |
| Manager  | manager@beansandbrews.com      | Manager@123    |
| Operator | operator@beansandbrews.com     | Operator@123   |

---

## 8. Using the Simulator

1. Go to **Simulator**, pick a machine and a coffee type, click **Dispense Coffee**.
   Watch the cup move into position, brewing/steam animation play, and the liquid
   fill the cup — inventory and dashboard stats update afterward.
2. Use the fault buttons (Low Water, Heater Failure, Machine Failure, Network
   Disconnection, etc.) to demonstrate alerting and status changes live.
3. Click **Restore Machine** to bring it back online.
4. Click **Start Demo Mode** to let the whole office generate realistic activity
   automatically every 15 seconds (useful for a hands-off presentation) — click
   **Stop Demo Mode** to pause it.

---

## 9. API Overview

```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/auth/me

GET    /api/machines            POST /api/machines (ADMIN)
GET    /api/machines/{id}       PUT  /api/machines/{id} (ADMIN)   DELETE (ADMIN)

GET    /api/consumption
GET    /api/consumption/today
GET    /api/consumption/machine/{machineId}

GET    /api/inventory
GET    /api/inventory/{machineId}
GET    /api/inventory/{machineId}/history

GET    /api/predictions
GET    /api/predictions/{machineId}

GET    /api/maintenance
GET    /api/maintenance/active
PUT    /api/maintenance/{id}/resolve
PUT    /api/maintenance/{id}/status

GET    /api/analytics/overview
GET    /api/analytics/coffee-preferences
GET    /api/analytics/peak-hours
GET    /api/analytics/departments
GET    /api/analytics/trend?range=daily|weekly|monthly

POST   /api/simulator/dispense
POST   /api/simulator/fault/{machineId}/{faultType}
POST   /api/simulator/start
POST   /api/simulator/stop
GET    /api/simulator/status

GET    /api/users (ADMIN)       DELETE /api/users/{id} (ADMIN)
```

All endpoints except `/api/auth/**` require a `Bearer <token>` header.

---

## 10. Troubleshooting

- **Backend won't connect to MySQL** — confirm MySQL is running on port 3306 and
  `DB_USERNAME`/`DB_PASSWORD` match your local setup.
- **CORS errors in the browser** — confirm `CORS_ORIGINS` includes
  `http://localhost:5173` (the Vite dev server's origin).
- **401 errors after login** — the JWT may have expired (default 24h); log in again.
- **Charts look empty right after a fresh clone** — the seeder only runs once, when
  the tables are empty. If you truncate `consumption_logs`, restart the backend to
  reseed, or trigger dispenses manually via the Simulator.

---

## 11. Future: MQTT Integration Plan

This version deliberately keeps the transport layer (REST) separate from business
logic (`service/`, `analytics/`, `prediction`-style logic inside `PredictionService`),
so a future version can introduce:

```
Coffee Machine Simulator → MQTT → Broker (Mosquitto/EMQX) → Spring Boot MQTT Subscriber
→ Event Processing (same services as today) → MySQL → React
```

The subscriber would simply call the same `SimulatorService`/`ConsumptionService`
methods that the current `SimulatorController` calls today — no redesign needed.
