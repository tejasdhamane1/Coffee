import React, { createContext, useContext, useState, useEffect } from 'react'
import { AuthAPI } from '../api/endpoints'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('bb_user')
    return stored ? JSON.parse(stored) : null
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('bb_token')
    if (!token) { setLoading(false); return }
    AuthAPI.me()
      .then((res) => {
        setUser(res.data)
        localStorage.setItem('bb_user', JSON.stringify(res.data))
      })
      .catch(() => {
        localStorage.removeItem('bb_token')
        localStorage.removeItem('bb_user')
        setUser(null)
      })
      .finally(() => setLoading(false))
  }, [])

  const login = async (email, password) => {
    const res = await AuthAPI.login({ email, password })
    localStorage.setItem('bb_token', res.data.token)
    const profile = { id: res.data.userId, name: res.data.name, email: res.data.email, role: res.data.role }
    localStorage.setItem('bb_user', JSON.stringify(profile))
    setUser(profile)
    return profile
  }

  const register = async (payload) => {
    const res = await AuthAPI.register(payload)
    localStorage.setItem('bb_token', res.data.token)
    const profile = { id: res.data.userId, name: res.data.name, email: res.data.email, role: res.data.role }
    localStorage.setItem('bb_user', JSON.stringify(profile))
    setUser(profile)
    return profile
  }

  const logout = () => {
    localStorage.removeItem('bb_token')
    localStorage.removeItem('bb_user')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
