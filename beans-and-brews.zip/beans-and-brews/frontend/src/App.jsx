import React from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { ToastProvider } from './components/Toast'
import ProtectedRoute from './components/ProtectedRoute'
import AppLayout from './components/AppLayout'

import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Machines from './pages/Machines'
import MachineDetails from './pages/MachineDetails'
import OfficeMap from './pages/OfficeMap'
import Simulator from './pages/Simulator'
import Consumption from './pages/Consumption'
import Inventory from './pages/Inventory'
import Maintenance from './pages/Maintenance'
import Predictions from './pages/Predictions'
import Users from './pages/Users'
import Settings from './pages/Settings'

function AuthedShell({ children }) {
  const location = useLocation()
  return <AppLayout pathname={location.pathname}>{children}</AppLayout>
}

function AppRoutes() {
  const { loading } = useAuth()
  if (loading) return <div style={{ padding: 40 }}>Loading...</div>

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route path="/dashboard" element={
        <ProtectedRoute><AuthedShell><Dashboard /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/machines" element={
        <ProtectedRoute><AuthedShell><Machines /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/machines/:id" element={
        <ProtectedRoute><AuthedShell><MachineDetails /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/office-map" element={
        <ProtectedRoute><AuthedShell><OfficeMap /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/simulator" element={
        <ProtectedRoute><AuthedShell><Simulator /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/consumption" element={
        <ProtectedRoute><AuthedShell><Consumption /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/inventory" element={
        <ProtectedRoute><AuthedShell><Inventory /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/maintenance" element={
        <ProtectedRoute><AuthedShell><Maintenance /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/predictions" element={
        <ProtectedRoute><AuthedShell><Predictions /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/users" element={
        <ProtectedRoute roles={['ADMIN']}><AuthedShell><Users /></AuthedShell></ProtectedRoute>
      } />
      <Route path="/settings" element={
        <ProtectedRoute><AuthedShell><Settings /></AuthedShell></ProtectedRoute>
      } />

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppRoutes />
      </ToastProvider>
    </AuthProvider>
  )
}
