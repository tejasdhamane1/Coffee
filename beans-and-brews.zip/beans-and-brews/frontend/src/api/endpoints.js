import client from './client'

export const AuthAPI = {
  login: (data) => client.post('/auth/login', data),
  register: (data) => client.post('/auth/register', data),
  me: () => client.get('/auth/me'),
}

export const MachineAPI = {
  getAll: () => client.get('/machines'),
  getById: (id) => client.get(`/machines/${id}`),
  create: (data) => client.post('/machines', data),
  update: (id, data) => client.put(`/machines/${id}`, data),
  remove: (id) => client.delete(`/machines/${id}`),
}

export const ConsumptionAPI = {
  getAll: () => client.get('/consumption'),
  getToday: () => client.get('/consumption/today'),
  byMachine: (id) => client.get(`/consumption/machine/${id}`),
}

export const InventoryAPI = {
  getAll: () => client.get('/inventory'),
  byMachine: (id) => client.get(`/inventory/${id}`),
  history: (id) => client.get(`/inventory/${id}/history`),
}

export const PredictionAPI = {
  getAll: () => client.get('/predictions'),
  byMachine: (id) => client.get(`/predictions/${id}`),
}

export const MaintenanceAPI = {
  getAll: () => client.get('/maintenance'),
  getActive: () => client.get('/maintenance/active'),
  getForMachine: (id) => client.get('/maintenance').then((res) => ({ data: res.data.filter((a) => a.machineId === id) })),
  resolve: (id) => client.put(`/maintenance/${id}/resolve`),
  updateStatus: (id, status) => client.put(`/maintenance/${id}/status`, { status }),
}

export const AnalyticsAPI = {
  overview: () => client.get('/analytics/overview'),
  coffeePreferences: () => client.get('/analytics/coffee-preferences'),
  peakHours: () => client.get('/analytics/peak-hours'),
  departments: () => client.get('/analytics/departments'),
  trend: (range = 'daily') => client.get(`/analytics/trend?range=${range}`),
}

export const SimulatorAPI = {
  dispense: (machineId, coffeeType) => client.post('/simulator/dispense', { machineId, coffeeType }),
  triggerFault: (machineId, faultType) => client.post(`/simulator/fault/${machineId}/${faultType}`),
  start: () => client.post('/simulator/start'),
  stop: () => client.post('/simulator/stop'),
  status: () => client.get('/simulator/status'),
}

export const UserAPI = {
  getAll: () => client.get('/users'),
  remove: (id) => client.delete(`/users/${id}`),
}
