import React from 'react'

export default function EmptyState({ icon: Icon, title, description }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--ink-soft)' }}>
      {Icon && <Icon size={32} style={{ marginBottom: 12, opacity: 0.5 }} />}
      <div style={{ fontWeight: 600, color: 'var(--ink)', marginBottom: 4 }}>{title}</div>
      {description && <div style={{ fontSize: 13 }}>{description}</div>}
    </div>
  )
}
