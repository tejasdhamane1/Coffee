import React from 'react'

export default function LoadingState({ label = 'Loading...' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '60px 0', color: 'var(--ink-soft)', fontSize: 14 }}>
      {label}
    </div>
  )
}
