import React, { createContext, useCallback, useContext, useState } from 'react'
import { CheckCircle2, XCircle, Info } from 'lucide-react'

const ToastContext = createContext(null)

let idCounter = 0

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])

  const push = useCallback((message, type = 'info') => {
    const id = ++idCounter
    setToasts((t) => [...t, { id, message, type }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500)
  }, [])

  return (
    <ToastContext.Provider value={{ push }}>
      {children}
      <div style={{ position: 'fixed', bottom: 24, right: 24, display: 'flex', flexDirection: 'column', gap: 10, zIndex: 1000 }}>
        {toasts.map((t) => (
          <div key={t.id} className="card" style={{
            padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10,
            minWidth: 260, boxShadow: 'var(--shadow-lg)',
            borderLeft: `4px solid ${t.type === 'error' ? 'var(--red)' : t.type === 'success' ? 'var(--green)' : 'var(--blue)'}`
          }}>
            {t.type === 'success' && <CheckCircle2 size={18} color="var(--green)" />}
            {t.type === 'error' && <XCircle size={18} color="var(--red)" />}
            {t.type === 'info' && <Info size={18} color="var(--blue)" />}
            <span style={{ fontSize: 14 }}>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export const useToast = () => useContext(ToastContext)
