import React from 'react'

export default function FilterBar({ children }) {
  return (
    <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginBottom: 18 }}>
      {children}
    </div>
  )
}
