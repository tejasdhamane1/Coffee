import React from 'react'
import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard, Coffee, Map, Sliders, BarChart3,
  Package, Wrench, TrendingUp, Users, Settings, LogOut
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/machines', label: 'Machines', icon: Coffee },
  { to: '/office-map', label: 'Office Map', icon: Map },
  { to: '/simulator', label: 'Simulator', icon: Sliders },
  { to: '/consumption', label: 'Consumption', icon: BarChart3 },
  { to: '/inventory', label: 'Inventory', icon: Package },
  { to: '/maintenance', label: 'Maintenance', icon: Wrench },
  { to: '/predictions', label: 'Predictions', icon: TrendingUp },
  { to: '/users', label: 'Users', icon: Users, adminOnly: true },
  { to: '/settings', label: 'Settings', icon: Settings },
]

export default function Sidebar() {
  const { user, logout } = useAuth()

  return (
    <aside style={{
      width: 240, background: 'var(--dark)', color: 'var(--cream)',
      display: 'flex', flexDirection: 'column', flexShrink: 0, position: 'sticky', top: 0, height: '100vh'
    }}>
      <div style={{ padding: '26px 22px 18px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 21, fontWeight: 600, color: 'var(--cream)' }}>
          Beans &amp; Brews
        </div>
        <div style={{ fontSize: 11, color: 'var(--latte)', marginTop: 2, letterSpacing: '0.03em' }}>
          SMART COFFEE. SMARTER INSIGHTS.
        </div>
      </div>

      <nav style={{ flex: 1, padding: '8px 12px', overflowY: 'auto' }}>
        {NAV_ITEMS.filter((item) => !item.adminOnly || user?.role === 'ADMIN').map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '10px 14px', borderRadius: 10, marginBottom: 4,
              fontSize: 14, fontWeight: 500,
              color: isActive ? 'var(--dark)' : 'rgba(247,241,232,0.75)',
              background: isActive ? 'var(--latte)' : 'transparent',
              transition: 'all 0.15s ease'
            })}
          >
            <Icon size={17} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div style={{ padding: 16, borderTop: '1px solid rgba(247,241,232,0.12)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{
            width: 34, height: 34, borderRadius: '50%', background: 'var(--caramel)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13
          }}>
            {user?.name?.charAt(0) || '?'}
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.name}
            </div>
            <div style={{ fontSize: 11, color: 'var(--latte)' }}>{user?.role}</div>
          </div>
        </div>
        <button
          onClick={logout}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'center',
            padding: '9px 0', borderRadius: 999, border: '1px solid rgba(247,241,232,0.2)',
            background: 'transparent', color: 'var(--cream)', fontSize: 13, fontWeight: 600
          }}
        >
          <LogOut size={15} /> Sign out
        </button>
      </div>
    </aside>
  )
}
