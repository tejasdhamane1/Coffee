import React from 'react'
import { Bell } from 'lucide-react'

export default function Navbar({ title, subtitle, activeAlerts = 0 }) {
  return (
    <header style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '18px 36px', borderBottom: '1px solid var(--border)', background: 'var(--surface-warm)'
    }}>
      <div>
        <div style={{ fontSize: 12, color: 'var(--ink-soft)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          {subtitle}
        </div>
        <div style={{ fontSize: 18, fontWeight: 600, fontFamily: 'var(--font-display)' }}>{title}</div>
      </div>
      <div style={{ position: 'relative' }}>
        <Bell size={20} color="var(--espresso)" />
        {activeAlerts > 0 && (
          <span style={{
            position: 'absolute', top: -6, right: -6, background: 'var(--red)', color: 'white',
            fontSize: 10, fontWeight: 700, borderRadius: 999, minWidth: 16, height: 16,
            display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 3px'
          }}>
            {activeAlerts}
          </span>
        )}
      </div>
    </header>
  )
}
