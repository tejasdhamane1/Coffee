import React from 'react'

function colorFor(level) {
  if (level <= 15) return 'var(--red)'
  if (level <= 40) return 'var(--amber)'
  return 'var(--green)'
}

export default function InventoryIndicator({ label, level }) {
  const pct = Math.max(0, Math.min(100, level))
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, marginBottom: 5 }}>
        <span style={{ color: 'var(--ink-soft)', fontWeight: 600 }}>{label}</span>
        <span style={{ fontWeight: 700, color: colorFor(pct) }}>{Math.round(pct)}%</span>
      </div>
      <div style={{ height: 7, borderRadius: 999, background: 'var(--border)', overflow: 'hidden' }}>
        <div style={{
          width: `${pct}%`, height: '100%', borderRadius: 999,
          background: colorFor(pct), transition: 'width 0.5s ease'
        }} />
      </div>
    </div>
  )
}
