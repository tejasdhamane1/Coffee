import React from 'react'
import { X } from 'lucide-react'

export default function Modal({ open, onClose, title, children, width = 480 }) {
  if (!open) return null
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(30, 18, 12, 0.45)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 900
    }} onClick={onClose}>
      <div className="card" style={{ width, maxWidth: '92vw', maxHeight: '85vh', overflowY: 'auto', padding: 24 }}
           onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
          <h3 style={{ fontSize: 18 }}>{title}</h3>
          <button onClick={onClose} className="btn btn-outline btn-sm" style={{ padding: 6 }}>
            <X size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
