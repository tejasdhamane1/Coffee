import React from 'react'
import Sidebar from './Sidebar'
import Navbar from './Navbar'
import usePolling from '../hooks/usePolling'
import { MaintenanceAPI } from '../api/endpoints'

const TITLES = {
  '/dashboard': ['Overview', 'Dashboard'],
  '/machines': ['Machine Network', 'Machines'],
  '/office-map': ['Floor Plan', 'Office Map'],
  '/simulator': ['Live Demo', 'Simulator'],
  '/consumption': ['Analytics', 'Consumption'],
  '/inventory': ['Monitoring', 'Inventory'],
  '/maintenance': ['Alerts', 'Maintenance'],
  '/predictions': ['Forecasting', 'Predictions'],
  '/users': ['Admin', 'Users'],
  '/settings': ['Account', 'Settings'],
}

export default function AppLayout({ children, pathname }) {
  const { data: activeAlerts } = usePolling(() => MaintenanceAPI.getActive().then((r) => r.data), 15000)
  const base = '/' + (pathname.split('/')[1] || 'dashboard')
  const [subtitle, title] = TITLES[base] || ['Beans and Brews', 'Overview']

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-area">
        <Navbar title={title} subtitle={subtitle} activeAlerts={(activeAlerts || []).length} />
        {children}
      </div>
    </div>
  )
}
