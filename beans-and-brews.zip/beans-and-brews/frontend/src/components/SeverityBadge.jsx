import React from 'react'

export default function SeverityBadge({ severity }) {
  const cls = `severity-${(severity || 'low').toLowerCase()}`
  return <span className={`badge ${cls}`}>{severity}</span>
}
