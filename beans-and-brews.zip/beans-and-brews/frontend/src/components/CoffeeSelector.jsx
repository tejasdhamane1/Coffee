import React from 'react'
import { Coffee } from 'lucide-react'

const COFFEES = [
  { type: 'ESPRESSO', label: 'Espresso' },
  { type: 'CAPPUCCINO', label: 'Cappuccino' },
  { type: 'LATTE', label: 'Latte' },
  { type: 'AMERICANO', label: 'Americano' },
  { type: 'MOCHA', label: 'Mocha' },
  { type: 'BLACK_COFFEE', label: 'Black Coffee' },
]

export default function CoffeeSelector({ selected, onSelect, disabled }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
      {COFFEES.map((c) => (
        <button
          key={c.type}
          disabled={disabled}
          onClick={() => onSelect(c.type)}
          className="btn"
          style={{
            flexDirection: 'column', padding: '14px 8px', borderRadius: 12,
            border: `1px solid ${selected === c.type ? 'var(--espresso)' : 'var(--border)'}`,
            background: selected === c.type ? 'var(--espresso)' : 'var(--surface)',
            color: selected === c.type ? 'var(--cream)' : 'var(--ink)',
            opacity: disabled ? 0.5 : 1,
            gap: 6
          }}
        >
          <Coffee size={18} />
          <span style={{ fontSize: 12.5 }}>{c.label}</span>
        </button>
      ))}
    </div>
  )
}
