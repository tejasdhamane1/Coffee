import React from 'react'
import { AlertOctagon, CheckCircle2 } from 'lucide-react'
import SeverityBadge from './SeverityBadge'

export default function AlertCard({ alert, onResolve }) {
  return (
    <div className="card" style={{ padding: 16, display: 'flex', gap: 14, alignItems: 'flex-start' }}>
      <div style={{
        width: 34, height: 34, borderRadius: 10, background: 'var(--red-soft)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
      }}>
        <AlertOctagon size={17} color="var(--red)" />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
          <div style={{ fontWeight: 700, fontSize: 13.5 }}>{alert.machineId} · {alert.alertType.replaceAll('_', ' ')}</div>
          <SeverityBadge severity={alert.severity} />
        </div>
        <div style={{ fontSize: 13, color: 'var(--ink-soft)', marginTop: 4 }}>{alert.message}</div>
        <div style={{ fontSize: 11.5, color: 'var(--ink-soft)', marginTop: 6 }}>
          {new Date(alert.createdAt).toLocaleString()} · {alert.status}
        </div>
      </div>
      {alert.status !== 'RESOLVED' && onResolve && (
        <button className="btn btn-outline btn-sm" onClick={() => onResolve(alert.id)}>
          <CheckCircle2 size={14} /> Resolve
        </button>
      )}
    </div>
  )
}
