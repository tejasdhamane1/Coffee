import React from 'react'
import { useNavigate } from 'react-router-dom'
import { MapPin, Thermometer } from 'lucide-react'
import StatusBadge from './StatusBadge'
import InventoryIndicator from './InventoryIndicator'

export default function MachineCard({ machine }) {
  const navigate = useNavigate()
  return (
    <div
      className="card"
      onClick={() => navigate(`/machines/${machine.machineId}`)}
      style={{ padding: 20, cursor: 'pointer', transition: 'box-shadow 0.15s ease' }}
      onMouseEnter={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-md)'}
      onMouseLeave={(e) => e.currentTarget.style.boxShadow = 'var(--shadow-sm)'}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 16, fontFamily: 'var(--font-display)' }}>{machine.machineId}</div>
          <div style={{ fontSize: 12.5, color: 'var(--ink-soft)', display: 'flex', alignItems: 'center', gap: 4, marginTop: 3 }}>
            <MapPin size={12} /> {machine.location} · {machine.department}
          </div>
        </div>
        <StatusBadge status={machine.status} />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, color: 'var(--ink-soft)', margin: '10px 0 14px' }}>
        <Thermometer size={13} /> {machine.temperature?.toFixed(1)}°C
      </div>

      <InventoryIndicator label="Coffee Powder" level={machine.coffeePowderLevel} />
      <InventoryIndicator label="Milk" level={machine.milkLevel} />
      <InventoryIndicator label="Water" level={machine.waterLevel} />
    </div>
  )
}
