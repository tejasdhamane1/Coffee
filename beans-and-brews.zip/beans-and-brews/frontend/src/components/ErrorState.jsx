import React from 'react'
import { AlertTriangle } from 'lucide-react'

export default function ErrorState({ message = 'Something went wrong.' }) {
  return (
    <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--red)' }}>
      <AlertTriangle size={28} style={{ marginBottom: 10 }} />
      <div style={{ fontWeight: 600 }}>{message}</div>
    </div>
  )
}
