import React from 'react'

export default function DashboardCard({ icon: Icon, label, value, accent = 'var(--coffee)', suffix }) {
  return (
    <div className="card" style={{ padding: '18px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{
        width: 36, height: 36, borderRadius: 10, background: `${accent}1A`,
        display: 'flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <Icon size={18} color={accent} />
      </div>
      <div>
        <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--dark)', fontFamily: 'var(--font-display)' }}>
          {value}{suffix && <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--ink-soft)' }}> {suffix}</span>}
        </div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginTop: 2 }}>{label}</div>
      </div>
    </div>
  )
}
