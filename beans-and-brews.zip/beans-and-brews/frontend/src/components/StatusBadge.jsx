import React from 'react'

const CONFIG = {
  ONLINE: { cls: 'badge-online', label: 'Online' },
  OFFLINE: { cls: 'badge-offline', label: 'Offline' },
  WARNING: { cls: 'badge-warning', label: 'Warning' },
  MAINTENANCE: { cls: 'badge-maintenance', label: 'Maintenance' },
}

export default function StatusBadge({ status }) {
  const cfg = CONFIG[status] || CONFIG.OFFLINE
  return (
    <span className={`badge ${cfg.cls}`}>
      <span className="badge-dot" />
      {cfg.label}
    </span>
  )
}
