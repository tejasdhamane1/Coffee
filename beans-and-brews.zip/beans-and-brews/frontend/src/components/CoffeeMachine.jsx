import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'

// Phases: idle -> selecting -> brewing -> dispensing -> done
export default function CoffeeMachine({ phase, coffeeName, machineId, temperature = 92 }) {
  const isActive = phase === 'brewing' || phase === 'dispensing'
  const isDone = phase === 'done'

  return (
    <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 4px' }}>
      <div style={{ position: 'relative', width: 300, height: 380 }}>

        {/* Machine body */}
        <div style={{
          position: 'absolute', inset: 0, borderRadius: '18px 18px 26px 26px',
          background: 'linear-gradient(160deg, #2a1a12 0%, #1E120C 55%, #150c07 100%)',
          boxShadow: '0 18px 40px rgba(30,18,12,0.35), inset 0 1px 0 rgba(255,255,255,0.05)',
          border: '1px solid #3B2416'
        }} />

        {/* Brand plate */}
        <div style={{
          position: 'absolute', top: 16, left: 0, right: 0, textAlign: 'center',
          color: '#D8B894', fontFamily: 'var(--font-display)', fontSize: 13, letterSpacing: '0.12em'
        }}>
          BEANS &amp; BREWS
        </div>

        {/* Digital display */}
        <div style={{
          position: 'absolute', top: 42, left: 24, right: 24, height: 54,
          borderRadius: 8, background: '#0c0906',
          border: '1px solid #3B2416', display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center', gap: 2
        }}>
          <div style={{ color: '#8CE0A8', fontSize: 11, fontFamily: 'monospace', letterSpacing: '0.05em' }}>
            {machineId}
          </div>
          <div style={{ color: '#F7F1E8', fontSize: 13, fontFamily: 'monospace', fontWeight: 700 }}>
            {phase === 'idle' && 'READY — SELECT COFFEE'}
            {phase === 'selecting' && `SELECTED: ${coffeeName?.toUpperCase()}`}
            {phase === 'brewing' && 'BREWING...'}
            {phase === 'dispensing' && 'DISPENSING...'}
            {phase === 'done' && 'ENJOY YOUR COFFEE'}
          </div>
          <div style={{ color: '#D8B894', fontSize: 9.5, fontFamily: 'monospace' }}>
            {temperature.toFixed(1)}°C
          </div>
        </div>

        {/* Control panel dots */}
        <div style={{ position: 'absolute', top: 106, left: 24, display: 'flex', gap: 8 }}>
          {['#A66A3F', '#6F4E37', '#3F8F5F', '#C1483C'].map((c, i) => (
            <div key={i} style={{
              width: 10, height: 10, borderRadius: '50%', background: c,
              opacity: isActive && i === 2 ? 1 : 0.55,
              boxShadow: isActive && i === 2 ? `0 0 8px ${c}` : 'none'
            }} />
          ))}
        </div>

        {/* Ingredient level mini gauges */}
        <div style={{ position: 'absolute', top: 106, right: 24, display: 'flex', gap: 6 }}>
          {['#F7F1E8', '#D8B894', '#6F4E37'].map((c, i) => (
            <div key={i} style={{ width: 6, height: 18, borderRadius: 3, background: '#3B2416', overflow: 'hidden', display: 'flex', alignItems: 'flex-end' }}>
              <div style={{ width: '100%', height: '70%', background: c }} />
            </div>
          ))}
        </div>

        {/* Nozzle */}
        <div style={{
          position: 'absolute', top: 150, left: '50%', transform: 'translateX(-50%)',
          width: 14, height: 46, borderRadius: '4px 4px 8px 8px',
          background: 'linear-gradient(90deg,#5a4030,#2a1c14)'
        }} />

        {/* Steam */}
        <AnimatePresence>
          {isActive && [0, 1, 2].map((i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 0, x: -4 + i * 4 }}
              animate={{ opacity: [0, 0.6, 0], y: -34, x: [-4 + i * 4, 2 + i * 3, -2 + i * 4] }}
              transition={{ duration: 1.6, repeat: Infinity, delay: i * 0.35 }}
              style={{
                position: 'absolute', top: 150, left: '50%', width: 6, height: 6,
                borderRadius: '50%', background: 'rgba(247,241,232,0.7)', filter: 'blur(2px)'
              }}
            />
          ))}
        </AnimatePresence>

        {/* Brewing liquid stream */}
        <AnimatePresence>
          {phase === 'dispensing' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 60, opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              style={{
                position: 'absolute', top: 196, left: '50%', transform: 'translateX(-50%)',
                width: 4, background: 'linear-gradient(180deg,#6F4E37,#3B2416)', borderRadius: 2
              }}
            />
          )}
        </AnimatePresence>

        {/* Drip tray platform */}
        <div style={{
          position: 'absolute', bottom: 40, left: '50%', transform: 'translateX(-50%)',
          width: 120, height: 10, borderRadius: 4, background: '#0c0906', border: '1px solid #3B2416'
        }} />

        {/* Cup */}
        <motion.div
          initial={{ x: -90, opacity: 0 }}
          animate={{
            x: phase === 'idle' ? -90 : 0,
            opacity: phase === 'idle' ? 0 : 1
          }}
          transition={{ type: 'spring', stiffness: 120, damping: 16 }}
          style={{
            position: 'absolute', bottom: 46, left: '50%', marginLeft: -22,
            width: 44, height: 54, borderRadius: '4px 4px 14px 14px',
            background: 'linear-gradient(160deg,#FFFFFF,#F7F1E8)',
            border: '1px solid #D8B894', overflow: 'hidden'
          }}
        >
          <motion.div
            initial={{ height: 0 }}
            animate={{
              height: phase === 'dispensing' ? '75%' : (isDone ? '75%' : 0)
            }}
            transition={{ duration: 2.2, ease: 'easeOut' }}
            style={{
              position: 'absolute', bottom: 0, left: 0, right: 0,
              background: 'linear-gradient(180deg,#6F4E37,#3B2416)'
            }}
          />
        </motion.div>

        {/* Base */}
        <div style={{
          position: 'absolute', bottom: 0, left: 0, right: 0, height: 26,
          borderRadius: '0 0 26px 26px', background: '#150c07'
        }} />
      </div>
    </div>
  )
}
