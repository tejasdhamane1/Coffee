import React from 'react'

export default function DataTable({ columns, data, rowKey }) {
  if (!data || data.length === 0) {
    return <div style={{ padding: 30, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 13.5 }}>No records found.</div>
  }
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13.5 }}>
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key} style={{
                textAlign: 'left', padding: '10px 14px', color: 'var(--ink-soft)',
                fontSize: 11.5, textTransform: 'uppercase', letterSpacing: '0.04em',
                borderBottom: '1px solid var(--border)'
              }}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row[rowKey]} style={{ borderBottom: '1px solid var(--border)' }}>
              {columns.map((col) => (
                <td key={col.key} style={{ padding: '11px 14px' }}>
                  {col.render ? col.render(row) : row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
