import { useEffect, useRef, useState, useCallback } from 'react'

/**
 * Polls an async fetcher on an interval so dashboards feel "real-time-like"
 * without needing WebSockets/MQTT. Returns { data, loading, error, refresh }.
 */
export default function usePolling(fetcher, intervalMs = 8000, deps = []) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const fetcherRef = useRef(fetcher)
  fetcherRef.current = fetcher

  const refresh = useCallback(async () => {
    try {
      const result = await fetcherRef.current()
      setData(result)
      setError(null)
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    let active = true
    setLoading(true)
    refresh()
    const id = setInterval(() => { if (active) refresh() }, intervalMs)
    return () => { active = false; clearInterval(id) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return { data, loading, error, refresh }
}
