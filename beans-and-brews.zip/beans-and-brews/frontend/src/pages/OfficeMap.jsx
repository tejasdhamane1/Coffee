import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Coffee } from 'lucide-react'
import Modal from '../components/Modal'
import StatusBadge from '../components/StatusBadge'
import InventoryIndicator from '../components/InventoryIndicator'
import LoadingState from '../components/LoadingState'
import usePolling from '../hooks/usePolling'
import { MachineAPI } from '../api/endpoints'

// Logical floor zones; machines are matched into a zone by department name.
const ZONES = [
  { key: 'reception', label: 'Reception', match: [], area: '1 / 1 / 2 / 2', color: '#EDE2CE' },
  { key: 'engineering', label: 'Engineering', match: ['engineering'], area: '1 / 2 / 3 / 4', color: '#E7DCC9' },
  { key: 'hr', label: 'HR', match: ['hr'], area: '2 / 1 / 3 / 2', color: '#EDE2CE' },
  { key: 'finance', label: 'Finance', match: ['finance'], area: '1 / 4 / 2 / 5', color: '#E7DCC9' },
  { key: 'meeting', label: 'Meeting Rooms', match: ['meeting'], area: '3 / 1 / 4 / 2', color: '#EDE2CE' },
  { key: 'cafeteria', label: 'Cafeteria', match: ['cafeteria'], area: '2 / 4 / 4 / 5', color: '#F1E6D2' },
  { key: 'management', label: 'Management', match: ['management'], area: '3 / 2 / 4 / 4', color: '#E7DCC9' },
]

function zoneFor(department) {
  const dep = department.toLowerCase()
  return ZONES.find((z) => z.match.some((m) => dep.includes(m))) || ZONES[0]
}

const STATUS_COLOR = { ONLINE: '#3F8F5F', OFFLINE: '#C1483C', WARNING: '#C08A2E', MAINTENANCE: '#3E6FA6' }

export default function OfficeMap() {
  const { data: machines, loading } = usePolling(() => MachineAPI.getAll().then((r) => r.data), 8000)
  const [selected, setSelected] = useState(null)
  const [activeLocation, setActiveLocation] = useState('All')
  const navigate = useNavigate()

  if (loading) return <LoadingState label="Loading office map..." />

  const locations = ['All', ...new Set((machines || []).map((m) => m.location))]
  const visible = (machines || []).filter((m) => activeLocation === 'All' || m.location === activeLocation)

  const positioned = {}
  visible.forEach((m) => {
    const zoneKey = zoneFor(m.department).key
    positioned[zoneKey] = positioned[zoneKey] || []
    positioned[zoneKey].push(m)
  })

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Office Floor Map</h1>
          <div className="subtitle">Interactive machine tracking across office zones.</div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {locations.map((loc) => (
          <button key={loc} onClick={() => setActiveLocation(loc)} className="btn btn-sm"
                  style={{
                    background: activeLocation === loc ? 'var(--espresso)' : 'var(--surface)',
                    color: activeLocation === loc ? 'var(--cream)' : 'var(--ink)',
                    border: '1px solid var(--border)'
                  }}>
            {loc}
          </button>
        ))}
      </div>

      <div className="card" style={{ padding: 24 }}>
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gridTemplateRows: 'repeat(3, 150px)',
          gap: 12
        }}>
          {ZONES.map((zone) => (
            <div key={zone.key} style={{
              gridArea: zone.area, background: zone.color, borderRadius: 16,
              border: '1px solid var(--border)', padding: 14, position: 'relative', overflow: 'hidden'
            }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-soft)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                {zone.label}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 10 }}>
                {(positioned[zone.key] || []).map((m) => (
                  <button
                    key={m.machineId}
                    onClick={() => setSelected(m)}
                    title={`${m.machineId} — ${m.status}`}
                    style={{
                      width: 46, height: 46, borderRadius: 12, border: 'none', cursor: 'pointer',
                      background: 'var(--dark)', display: 'flex', flexDirection: 'column',
                      alignItems: 'center', justifyContent: 'center', position: 'relative',
                      boxShadow: '0 4px 10px rgba(30,18,12,0.2)'
                    }}
                  >
                    <Coffee size={16} color="var(--cream)" />
                    <span style={{
                      position: 'absolute', top: -4, right: -4, width: 12, height: 12, borderRadius: '50%',
                      background: STATUS_COLOR[m.status], border: '2px solid var(--surface)'
                    }} />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 18, marginTop: 20, flexWrap: 'wrap' }}>
          {Object.entries(STATUS_COLOR).map(([status, color]) => (
            <div key={status} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12.5, color: 'var(--ink-soft)' }}>
              <span style={{ width: 9, height: 9, borderRadius: '50%', background: color }} />
              {status}
            </div>
          ))}
        </div>
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected?.machineId}>
        {selected && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
              <div style={{ fontSize: 13.5, color: 'var(--ink-soft)' }}>{selected.location} · {selected.department}</div>
              <StatusBadge status={selected.status} />
            </div>
            <InventoryIndicator label="Coffee Powder" level={selected.coffeePowderLevel} />
            <InventoryIndicator label="Milk" level={selected.milkLevel} />
            <InventoryIndicator label="Water" level={selected.waterLevel} />
            <div style={{ fontSize: 13, color: 'var(--ink-soft)', margin: '14px 0 18px' }}>
              Temperature: {selected.temperature?.toFixed(1)}°C
            </div>
            <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}
                    onClick={() => navigate(`/machines/${selected.machineId}`)}>
              View Full Details
            </button>
          </div>
        )}
      </Modal>
    </div>
  )
}
