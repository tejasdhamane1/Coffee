import React from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, MapPin, Thermometer, Clock, AlertOctagon } from 'lucide-react'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts'
import StatusBadge from '../components/StatusBadge'
import InventoryIndicator from '../components/InventoryIndicator'
import ChartCard from '../components/ChartCard'
import LoadingState from '../components/LoadingState'
import CoffeeMachine from '../components/CoffeeMachine'
import usePolling from '../hooks/usePolling'
import { MachineAPI, ConsumptionAPI, MaintenanceAPI } from '../api/endpoints'

export default function MachineDetails() {
  const { id } = useParams()
  const navigate = useNavigate()

  const { data: machine, loading } = usePolling(() => MachineAPI.getById(id).then((r) => r.data), 8000, [id])
  const { data: logs } = usePolling(() => ConsumptionAPI.byMachine(id).then((r) => r.data), 15000, [id])
  const { data: alerts } = usePolling(() => MaintenanceAPI.getForMachine(id).then((r) => r.data), 15000, [id])

  if (loading || !machine) return <LoadingState label="Loading machine..." />

  const hourly = {}
  ;(logs || []).forEach((l) => {
    const hour = new Date(l.timestamp).getHours()
    hourly[hour] = (hourly[hour] || 0) + l.cupsDispensed
  })
  const chartData = Array.from({ length: 24 }, (_, h) => ({ hour: h, cups: hourly[h] || 0 }))

  return (
    <div className="page">
      <button className="btn btn-outline btn-sm" style={{ marginBottom: 16 }} onClick={() => navigate('/machines')}>
        <ArrowLeft size={14} /> Back to Machines
      </button>

      <div className="page-header">
        <div>
          <h1>{machine.machineId}</h1>
          <div className="subtitle" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <MapPin size={13} /> {machine.location} · {machine.department}
          </div>
        </div>
        <StatusBadge status={machine.status} />
      </div>

      <div className="grid grid-cols-2" style={{ marginBottom: 22 }}>
        <div className="card" style={{ padding: 22 }}>
          <CoffeeMachine phase="idle" machineId={machine.machineId} temperature={machine.temperature} />
        </div>

        <div className="card" style={{ padding: 22 }}>
          <div style={{ fontWeight: 600, marginBottom: 16, fontFamily: 'var(--font-display)' }}>Live Inventory</div>
          <InventoryIndicator label="Coffee Powder" level={machine.coffeePowderLevel} />
          <InventoryIndicator label="Milk" level={machine.milkLevel} />
          <InventoryIndicator label="Water" level={machine.waterLevel} />

          <div style={{ display: 'flex', gap: 20, marginTop: 20, flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--ink-soft)' }}>
              <Thermometer size={15} /> {machine.temperature?.toFixed(1)}°C
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--ink-soft)' }}>
              <Clock size={15} /> Downtime: {machine.totalDowntimeMinutes || 0} min
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--ink-soft)' }}>
              <AlertOctagon size={15} /> Failures: {machine.failureCount || 0}
            </div>
          </div>
        </div>
      </div>

      <ChartCard title="Consumption History" subtitle="Cups dispensed by hour" >
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="hour" tickFormatter={(h) => `${h}:00`} tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} />
            <Tooltip />
            <Line type="monotone" dataKey="cups" stroke="var(--coffee)" strokeWidth={2.5} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ height: 22 }} />

      <ChartCard title="Alerts for this machine">
        {(!alerts || alerts.length === 0) ? (
          <div style={{ padding: '16px 0', color: 'var(--ink-soft)', fontSize: 13.5 }}>No alerts recorded.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {alerts.map((a) => (
              <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13.5 }}>
                <span>{a.alertType.replaceAll('_', ' ')} — {a.message}</span>
                <span style={{ color: 'var(--ink-soft)', fontSize: 12 }}>{a.status}</span>
              </div>
            ))}
          </div>
        )}
      </ChartCard>
    </div>
  )
}
