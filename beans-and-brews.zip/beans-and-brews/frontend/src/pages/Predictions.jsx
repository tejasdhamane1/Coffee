import React from 'react'
import { Droplets, Milk, Coffee as CoffeeIcon, TrendingDown } from 'lucide-react'
import LoadingState from '../components/LoadingState'
import usePolling from '../hooks/usePolling'
import { PredictionAPI } from '../api/endpoints'

const ICONS = { WATER: Droplets, MILK: Milk, COFFEE_POWDER: CoffeeIcon }

function urgencyColor(days) {
  if (days === null || days === undefined) return 'var(--ink-soft)'
  if (days <= 1) return 'var(--red)'
  if (days <= 3) return 'var(--amber)'
  return 'var(--green)'
}

export default function Predictions() {
  const { data: predictions, loading } = usePolling(() => PredictionAPI.getAll().then((r) => r.data), 15000)

  if (loading) return <LoadingState label="Calculating refill predictions..." />

  // Keep only the latest prediction per (machine, inventoryType)
  const latest = new Map()
  ;(predictions || []).forEach((p) => {
    const key = `${p.machineId}-${p.inventoryType}`
    const existing = latest.get(key)
    if (!existing || new Date(p.createdAt) > new Date(existing.createdAt)) {
      latest.set(key, p)
    }
  })

  const byMachine = {}
  Array.from(latest.values()).forEach((p) => {
    byMachine[p.machineId] = byMachine[p.machineId] || []
    byMachine[p.machineId].push(p)
  })

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Refill Predictions</h1>
          <div className="subtitle">Estimated days remaining = remaining inventory ÷ average daily consumption.</div>
        </div>
      </div>

      <div className="grid grid-cols-3">
        {Object.entries(byMachine).map(([machineId, items]) => (
          <div key={machineId} className="card" style={{ padding: 20 }}>
            <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'var(--font-display)', marginBottom: 14 }}>
              {machineId}
            </div>
            {items.map((p) => {
              const Icon = ICONS[p.inventoryType] || TrendingDown
              return (
                <div key={p.inventoryType} style={{ marginBottom: 16, paddingBottom: 14, borderBottom: '1px solid var(--border)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <Icon size={14} color="var(--ink-soft)" />
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{p.inventoryType.replaceAll('_', ' ')}</span>
                  </div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: urgencyColor(p.estimatedDaysRemaining), fontFamily: 'var(--font-display)' }}>
                    {p.estimatedDaysRemaining} days
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--ink-soft)', marginTop: 4 }}>{p.recommendedAction}</div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  )
}
