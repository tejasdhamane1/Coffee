import React from 'react'
import { Droplets, Milk, Coffee as CoffeeIcon } from 'lucide-react'
import InventoryIndicator from '../components/InventoryIndicator'
import LoadingState from '../components/LoadingState'
import usePolling from '../hooks/usePolling'
import { InventoryAPI } from '../api/endpoints'

export default function Inventory() {
  const { data: inventory, loading } = usePolling(() => InventoryAPI.getAll().then((r) => r.data), 8000)

  if (loading) return <LoadingState label="Loading inventory..." />

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Inventory Monitoring</h1>
          <div className="subtitle">Water, milk, and coffee powder levels across every machine.</div>
        </div>
      </div>

      <div className="grid grid-cols-3">
        {(inventory || []).map((item) => (
          <div key={item.machineId} className="card" style={{ padding: 20 }}>
            <div style={{ fontWeight: 700, fontSize: 15, fontFamily: 'var(--font-display)', marginBottom: 16 }}>
              {item.machineId}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
              <CoffeeIcon size={13} color="var(--ink-soft)" />
            </div>
            <InventoryIndicator label="Coffee Powder" level={item.coffeePowderLevel} />

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
              <Milk size={13} color="var(--ink-soft)" />
            </div>
            <InventoryIndicator label="Milk" level={item.milkLevel} />

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
              <Droplets size={13} color="var(--ink-soft)" />
            </div>
            <InventoryIndicator label="Water" level={item.waterLevel} />

            <div style={{ fontSize: 11.5, color: 'var(--ink-soft)', marginTop: 8 }}>
              Updated {item.updatedAt ? new Date(item.updatedAt).toLocaleString() : '—'}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
