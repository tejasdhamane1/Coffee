import React from 'react'
import { useAuth } from '../context/AuthContext'

export default function Settings() {
  const { user } = useAuth()

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Settings</h1>
          <div className="subtitle">Account and system information.</div>
        </div>
      </div>

      <div className="grid grid-cols-2">
        <div className="card" style={{ padding: 22 }}>
          <div style={{ fontWeight: 600, marginBottom: 16, fontFamily: 'var(--font-display)' }}>Account</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13.5 }}>
            <div><span className="label" style={{ display: 'inline', marginRight: 6 }}>Name</span>{user?.name}</div>
            <div><span className="label" style={{ display: 'inline', marginRight: 6 }}>Email</span>{user?.email}</div>
            <div><span className="label" style={{ display: 'inline', marginRight: 6 }}>Role</span>{user?.role}</div>
          </div>
        </div>

        <div className="card" style={{ padding: 22 }}>
          <div style={{ fontWeight: 600, marginBottom: 16, fontFamily: 'var(--font-display)' }}>System</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13.5, color: 'var(--ink-soft)' }}>
            <div>Backend: Spring Boot + MySQL (REST, no MQTT — planned for a future release)</div>
            <div>Frontend: React + Vite</div>
            <div>Version: 1.0.0</div>
          </div>
        </div>
      </div>
    </div>
  )
}
