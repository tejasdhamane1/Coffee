import React, { useState } from 'react'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar } from 'recharts'
import ChartCard from '../components/ChartCard'
import DataTable from '../components/DataTable'
import LoadingState from '../components/LoadingState'
import FilterBar from '../components/FilterBar'
import usePolling from '../hooks/usePolling'
import { AnalyticsAPI, ConsumptionAPI } from '../api/endpoints'

export default function Consumption() {
  const [range, setRange] = useState('daily')
  const { data: trend, loading } = usePolling(() => AnalyticsAPI.trend(range).then((r) => r.data), 15000, [range])
  const { data: departments } = usePolling(() => AnalyticsAPI.departments().then((r) => r.data), 20000)
  const { data: today } = usePolling(() => ConsumptionAPI.getToday().then((r) => r.data), 10000)

  if (loading) return <LoadingState label="Loading consumption analytics..." />

  const recentLogs = (today?.logs || [])
    .slice()
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 12)

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Consumption Analytics</h1>
          <div className="subtitle">Cups dispensed across machines, departments, and time.</div>
        </div>
      </div>

      <FilterBar>
        {['daily', 'weekly', 'monthly'].map((r) => (
          <button key={r} onClick={() => setRange(r)} className="btn btn-sm"
                  style={{
                    background: range === r ? 'var(--espresso)' : 'var(--surface)',
                    color: range === r ? 'var(--cream)' : 'var(--ink)',
                    border: '1px solid var(--border)'
                  }}>
            {r.charAt(0).toUpperCase() + r.slice(1)}
          </button>
        ))}
      </FilterBar>

      <ChartCard title="Consumption Trend" subtitle={`Grouped ${range}`}>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={trend?.series || []}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="period" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} />
            <Tooltip />
            <Line type="monotone" dataKey="cups" stroke="var(--coffee)" strokeWidth={2.5} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <div style={{ height: 22 }} />

      <div className="grid grid-cols-2">
        <ChartCard title="Cups by Department">
          <ResponsiveContainer width="100%" height={230}>
            <BarChart data={departments?.departments || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="department" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="cups" fill="var(--caramel)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Recent Activity" subtitle="Latest dispensed cups today">
          <DataTable
            rowKey="id"
            columns={[
              { key: 'machineId', label: 'Machine' },
              { key: 'coffeeType', label: 'Coffee', render: (r) => r.coffeeType.replaceAll('_', ' ') },
              { key: 'cupsDispensed', label: 'Cups' },
              { key: 'timestamp', label: 'Time', render: (r) => new Date(r.timestamp).toLocaleTimeString() },
            ]}
            data={recentLogs}
          />
        </ChartCard>
      </div>
    </div>
  )
}
