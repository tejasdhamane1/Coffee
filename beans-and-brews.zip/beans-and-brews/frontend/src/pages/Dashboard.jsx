import React from 'react'
import { Coffee, Wifi, WifiOff, Wrench, TrendingUp, Star, PackageX, AlertTriangle } from 'lucide-react'
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, PieChart, Pie, Cell
} from 'recharts'
import DashboardCard from '../components/DashboardCard'
import ChartCard from '../components/ChartCard'
import LoadingState from '../components/LoadingState'
import StatusBadge from '../components/StatusBadge'
import usePolling from '../hooks/usePolling'
import { AnalyticsAPI, MachineAPI, MaintenanceAPI } from '../api/endpoints'

const COLORS = ['#3B2416', '#A66A3F', '#6F4E37', '#D8B894', '#C08A2E', '#3F8F5F']

export default function Dashboard() {
  const overview = usePolling(() => AnalyticsAPI.overview().then((r) => r.data), 10000)
  const machines = usePolling(() => MachineAPI.getAll().then((r) => r.data), 10000)
  const preferences = usePolling(() => AnalyticsAPI.coffeePreferences().then((r) => r.data), 20000)
  const peakHours = usePolling(() => AnalyticsAPI.peakHours().then((r) => r.data), 20000)
  const activeAlerts = usePolling(() => MaintenanceAPI.getActive().then((r) => r.data), 10000)

  if (overview.loading || machines.loading) return <LoadingState label="Loading dashboard..." />

  const ov = overview.data || {}

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Centralized Dashboard</h1>
          <div className="subtitle">Live view across all offices and machines.</div>
        </div>
      </div>

      <div className="grid grid-cols-4" style={{ marginBottom: 22 }}>
        <DashboardCard icon={Coffee} label="Total Machines" value={ov.totalMachines ?? '—'} accent="#3B2416" />
        <DashboardCard icon={Wifi} label="Online Machines" value={ov.onlineMachines ?? '—'} accent="#3F8F5F" />
        <DashboardCard icon={WifiOff} label="Offline Machines" value={ov.offlineMachines ?? '—'} accent="#C1483C" />
        <DashboardCard icon={Wrench} label="In Maintenance" value={ov.maintenanceMachines ?? '—'} accent="#3E6FA6" />
      </div>

      <div className="grid grid-cols-4" style={{ marginBottom: 22 }}>
        <DashboardCard icon={TrendingUp} label="Cups Dispensed Today" value={ov.cupsDispensedToday ?? '—'} accent="#A66A3F" />
        <DashboardCard icon={TrendingUp} label="Avg Daily Consumption" value={ov.averageDailyConsumption ?? '—'} accent="#6F4E37" suffix="cups/day" />
        <DashboardCard icon={Star} label="Most Popular Coffee" value={(ov.mostPopularCoffee || '—').replaceAll('_', ' ')} accent="#C08A2E" />
        <DashboardCard icon={PackageX} label="Machines Needing Refill" value={ov.machinesRequiringRefill ?? '—'} accent="#C1483C" />
      </div>

      <div className="grid grid-cols-2" style={{ marginBottom: 22 }}>
        <ChartCard title="Coffee Preference Distribution" subtitle="All-time cups by coffee type">
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={(preferences.data?.distribution || []).filter(d => d.cups > 0)}
                dataKey="cups" nameKey="coffeeType" innerRadius={55} outerRadius={85} paddingAngle={2}
              >
                {(preferences.data?.distribution || []).map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Peak Usage Hours" subtitle={`Peak period: ${peakHours.data?.peakPeriod || '—'}`}>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={peakHours.data?.hourly || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="hour" tickFormatter={(h) => `${h}:00`} tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="cups" fill="var(--caramel)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid grid-cols-2">
        <ChartCard title="Machine Status Overview">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {(machines.data || []).map((m) => (
              <div key={m.machineId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13.5 }}>{m.machineId} — {m.location}</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{m.department}</div>
                </div>
                <StatusBadge status={m.status} />
              </div>
            ))}
          </div>
        </ChartCard>

        <ChartCard title="Active Alerts" subtitle={`${activeAlerts.data?.length || 0} requiring attention`}>
          {(activeAlerts.data || []).length === 0 ? (
            <div style={{ padding: '20px 0', textAlign: 'center', color: 'var(--ink-soft)', fontSize: 13.5 }}>
              No active alerts. All machines healthy.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {activeAlerts.data.slice(0, 5).map((a) => (
                <div key={a.id} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                  <AlertTriangle size={16} color="var(--red)" style={{ marginTop: 2 }} />
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13 }}>{a.machineId} · {a.alertType.replaceAll('_', ' ')}</div>
                    <div style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{a.message}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ChartCard>
      </div>
    </div>
  )
}
