import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Coffee } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'OPERATOR' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }))

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      await register(form)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'radial-gradient(circle at 20% 20%, #3B2416, #1E120C 65%)'
    }}>
      <div className="card" style={{ width: 400, padding: 36 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--espresso)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Coffee size={20} color="var(--cream)" />
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 19 }}>Create account</div>
        </div>

        <form onSubmit={submit} style={{ marginTop: 20 }}>
          <label className="label">Full name</label>
          <input className="input" style={{ marginBottom: 14 }} value={form.name} onChange={update('name')} required />

          <label className="label">Email</label>
          <input className="input" style={{ marginBottom: 14 }} type="email" value={form.email} onChange={update('email')} required />

          <label className="label">Password</label>
          <input className="input" style={{ marginBottom: 14 }} type="password" value={form.password} onChange={update('password')} required />

          <label className="label">Role</label>
          <select className="input" style={{ marginBottom: 18 }} value={form.role} onChange={update('role')}>
            <option value="OPERATOR">Operator</option>
            <option value="MANAGER">Manager</option>
            <option value="ADMIN">Admin</option>
          </select>

          {error && <div style={{ color: 'var(--red)', fontSize: 13, marginBottom: 14 }}>{error}</div>}

          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
            {busy ? 'Creating account...' : 'Create account'}
          </button>
        </form>

        <div style={{ textAlign: 'center', marginTop: 16, fontSize: 13.5 }}>
          Already registered? <Link to="/login" style={{ color: 'var(--coffee)', fontWeight: 600 }}>Sign in</Link>
        </div>
      </div>
    </div>
  )
}
