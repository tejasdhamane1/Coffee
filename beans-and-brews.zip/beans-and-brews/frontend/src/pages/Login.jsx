import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Coffee } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('admin@beansandbrews.com')
  const [password, setPassword] = useState('Admin@123')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      await login(email, password)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Check your credentials.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'radial-gradient(circle at 20% 20%, #3B2416, #1E120C 65%)'
    }}>
      <div className="card" style={{ width: 400, padding: 36 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--espresso)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Coffee size={20} color="var(--cream)" />
          </div>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 19 }}>Beans and Brews</div>
            <div style={{ fontSize: 11.5, color: 'var(--ink-soft)' }}>Smart Coffee. Smarter Insights.</div>
          </div>
        </div>

        <h2 style={{ fontSize: 20, margin: '24px 0 4px' }}>Welcome back</h2>
        <p style={{ color: 'var(--ink-soft)', fontSize: 13.5, marginBottom: 22 }}>Sign in to your office coffee network.</p>

        <form onSubmit={submit}>
          <label className="label">Email</label>
          <input className="input" style={{ marginBottom: 14 }} type="email" value={email}
                 onChange={(e) => setEmail(e.target.value)} required />

          <label className="label">Password</label>
          <input className="input" style={{ marginBottom: 18 }} type="password" value={password}
                 onChange={(e) => setPassword(e.target.value)} required />

          {error && <div style={{ color: 'var(--red)', fontSize: 13, marginBottom: 14 }}>{error}</div>}

          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={busy}>
            {busy ? 'Signing in...' : 'Sign in'}
          </button>
        </form>

        <div style={{ fontSize: 12.5, color: 'var(--ink-soft)', marginTop: 18, lineHeight: 1.6 }}>
          Demo accounts: <br />
          admin@beansandbrews.com / Admin@123 (Admin)<br />
          manager@beansandbrews.com / Manager@123 (Manager)<br />
          operator@beansandbrews.com / Operator@123 (Operator)
        </div>

        <div style={{ textAlign: 'center', marginTop: 16, fontSize: 13.5 }}>
          No account? <Link to="/register" style={{ color: 'var(--coffee)', fontWeight: 600 }}>Register</Link>
        </div>
      </div>
    </div>
  )
}
