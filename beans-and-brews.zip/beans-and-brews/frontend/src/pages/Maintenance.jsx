import React, { useState } from 'react'
import AlertCard from '../components/AlertCard'
import LoadingState from '../components/LoadingState'
import EmptyState from '../components/EmptyState'
import FilterBar from '../components/FilterBar'
import { CheckCircle2 } from 'lucide-react'
import usePolling from '../hooks/usePolling'
import { MaintenanceAPI } from '../api/endpoints'
import { useToast } from '../components/Toast'

export default function Maintenance() {
  const [filter, setFilter] = useState('ALL')
  const { data: alerts, loading, refresh } = usePolling(() => MaintenanceAPI.getAll().then((r) => r.data), 8000)
  const toast = useToast()

  const resolve = async (id) => {
    try {
      await MaintenanceAPI.resolve(id)
      toast.push('Alert marked as resolved.', 'success')
      refresh()
    } catch {
      toast.push('Failed to resolve alert.', 'error')
    }
  }

  if (loading) return <LoadingState label="Loading maintenance alerts..." />

  const filtered = (alerts || []).filter((a) => filter === 'ALL' || a.status === filter)

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Maintenance &amp; Alerts</h1>
          <div className="subtitle">{(alerts || []).filter(a => a.status === 'ACTIVE').length} alerts currently active.</div>
        </div>
      </div>

      <FilterBar>
        {['ALL', 'ACTIVE', 'ACKNOWLEDGED', 'RESOLVED'].map((s) => (
          <button key={s} onClick={() => setFilter(s)} className="btn btn-sm"
                  style={{
                    background: filter === s ? 'var(--espresso)' : 'var(--surface)',
                    color: filter === s ? 'var(--cream)' : 'var(--ink)',
                    border: '1px solid var(--border)'
                  }}>
            {s.charAt(0) + s.slice(1).toLowerCase()}
          </button>
        ))}
      </FilterBar>

      {filtered.length === 0 ? (
        <EmptyState icon={CheckCircle2} title="No alerts here" description="Everything is running smoothly." />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {filtered.map((a) => <AlertCard key={a.id} alert={a} onResolve={resolve} />)}
        </div>
      )}
    </div>
  )
}
