import React from 'react'
import { Trash2 } from 'lucide-react'
import DataTable from '../components/DataTable'
import LoadingState from '../components/LoadingState'
import usePolling from '../hooks/usePolling'
import { UserAPI } from '../api/endpoints'
import { useToast } from '../components/Toast'
import { useAuth } from '../context/AuthContext'

export default function Users() {
  const { user: currentUser } = useAuth()
  const toast = useToast()
  const { data: users, loading, refresh } = usePolling(() => UserAPI.getAll().then((r) => r.data), 15000)

  const remove = async (id) => {
    if (id === currentUser?.id) {
      toast.push("You can't remove your own account.", 'info')
      return
    }
    try {
      await UserAPI.remove(id)
      toast.push('User removed.', 'success')
      refresh()
    } catch {
      toast.push('Failed to remove user.', 'error')
    }
  }

  if (loading) return <LoadingState label="Loading users..." />

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>User Management</h1>
          <div className="subtitle">Admin-only — manage platform users and roles.</div>
        </div>
      </div>

      <div className="card" style={{ padding: 8 }}>
        <DataTable
          rowKey="id"
          data={users}
          columns={[
            { key: 'name', label: 'Name' },
            { key: 'email', label: 'Email' },
            { key: 'role', label: 'Role' },
            { key: 'createdAt', label: 'Joined', render: (r) => new Date(r.createdAt).toLocaleDateString() },
            {
              key: 'actions', label: '', render: (r) => (
                <button className="btn btn-danger btn-sm" onClick={() => remove(r.id)}>
                  <Trash2 size={13} /> Remove
                </button>
              )
            },
          ]}
        />
      </div>
    </div>
  )
}
