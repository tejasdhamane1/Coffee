import React, { useState } from 'react'
import { Play, Square, Zap, Droplets, Milk, Coffee as CoffeeIcon, Thermometer, WifiOff, PowerOff, RotateCcw } from 'lucide-react'
import CoffeeMachine from '../components/CoffeeMachine'
import CoffeeSelector from '../components/CoffeeSelector'
import LoadingState from '../components/LoadingState'
import usePolling from '../hooks/usePolling'
import { MachineAPI, SimulatorAPI } from '../api/endpoints'
import { useToast } from '../components/Toast'

const COFFEE_LABELS = {
  ESPRESSO: 'Espresso', CAPPUCCINO: 'Cappuccino', LATTE: 'Latte',
  AMERICANO: 'Americano', MOCHA: 'Mocha', BLACK_COFFEE: 'Black Coffee'
}

const FAULTS = [
  { key: 'LOW_WATER', label: 'Low Water', icon: Droplets },
  { key: 'LOW_MILK', label: 'Low Milk', icon: Milk },
  { key: 'LOW_COFFEE_POWDER', label: 'Low Coffee Powder', icon: CoffeeIcon },
  { key: 'HIGH_TEMPERATURE', label: 'High Temperature', icon: Thermometer },
  { key: 'HEATER_FAILURE', label: 'Heater Failure', icon: Zap },
  { key: 'MACHINE_FAILURE', label: 'Machine Failure', icon: PowerOff },
  { key: 'NETWORK_DISCONNECTION', label: 'Network Disconnection', icon: WifiOff },
  { key: 'MACHINE_OFFLINE', label: 'Machine Offline', icon: PowerOff },
]

export default function Simulator() {
  const { data: machines, loading, refresh } = usePolling(() => MachineAPI.getAll().then((r) => r.data), 6000)
  const toast = useToast()
  const [machineId, setMachineId] = useState('')
  const [coffeeType, setCoffeeType] = useState(null)
  const [phase, setPhase] = useState('idle')
  const [demoRunning, setDemoRunning] = useState(false)

  const activeMachineId = machineId || machines?.[0]?.machineId
  const machine = (machines || []).find((m) => m.machineId === activeMachineId)

  const runDispense = async () => {
    if (!activeMachineId || !coffeeType) {
      toast.push('Select a machine and coffee type first.', 'info')
      return
    }
    if (phase !== 'idle') return

    setPhase('selecting')
    await wait(500)
    setPhase('brewing')
    await wait(1400)
    setPhase('dispensing')

    try {
      await SimulatorAPI.dispense(activeMachineId, coffeeType)
      await wait(2200)
      setPhase('done')
      toast.push(`${COFFEE_LABELS[coffeeType]} dispensed from ${activeMachineId}.`, 'success')
      refresh()
    } catch (err) {
      toast.push(err.response?.data?.message || 'Dispense failed.', 'error')
    } finally {
      await wait(1200)
      setPhase('idle')
      setCoffeeType(null)
    }
  }

  const triggerFault = async (fault) => {
    if (!activeMachineId) return
    try {
      await SimulatorAPI.triggerFault(activeMachineId, fault)
      toast.push(`Fault "${fault.replaceAll('_', ' ')}" applied to ${activeMachineId}.`, 'info')
      refresh()
    } catch (err) {
      toast.push('Failed to apply fault.', 'error')
    }
  }

  const restore = async () => {
    if (!activeMachineId) return
    await SimulatorAPI.triggerFault(activeMachineId, 'RESTORE')
    toast.push(`${activeMachineId} restored to normal operation.`, 'success')
    refresh()
  }

  const toggleDemo = async () => {
    if (demoRunning) {
      await SimulatorAPI.stop()
      setDemoRunning(false)
      toast.push('Demo mode stopped.', 'info')
    } else {
      await SimulatorAPI.start()
      setDemoRunning(true)
      toast.push('Demo mode started — office activity will simulate automatically.', 'success')
    }
  }

  if (loading) return <LoadingState label="Loading simulator..." />

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Interactive Coffee Machine Simulator</h1>
          <div className="subtitle">Trigger real machine behaviour for demos and testing.</div>
        </div>
        <button className="btn btn-primary" onClick={toggleDemo}>
          {demoRunning ? <Square size={15} /> : <Play size={15} />}
          {demoRunning ? 'Stop Demo Mode' : 'Start Demo Mode'}
        </button>
      </div>

      <div className="grid grid-cols-2">
        <div className="card" style={{ padding: 24 }}>
          <label className="label">Select Machine</label>
          <select className="input" style={{ marginBottom: 18 }} value={activeMachineId}
                  onChange={(e) => setMachineId(e.target.value)}>
            {(machines || []).map((m) => (
              <option key={m.machineId} value={m.machineId}>
                {m.machineId} — {m.location} ({m.department}) — {m.status}
              </option>
            ))}
          </select>

          {machine && (
            <CoffeeMachine
              phase={phase}
              coffeeName={coffeeType ? COFFEE_LABELS[coffeeType] : ''}
              machineId={machine.machineId}
              temperature={machine.temperature}
            />
          )}

          <div style={{ marginTop: 14 }}>
            <label className="label">Choose Coffee</label>
            <CoffeeSelector selected={coffeeType} onSelect={setCoffeeType} disabled={phase !== 'idle'} />
          </div>

          <button
            className="btn btn-primary"
            style={{ width: '100%', justifyContent: 'center', marginTop: 18 }}
            disabled={phase !== 'idle' || !coffeeType}
            onClick={runDispense}
          >
            {phase === 'idle' ? 'Dispense Coffee' : 'Preparing...'}
          </button>
        </div>

        <div className="card" style={{ padding: 24 }}>
          <div style={{ fontWeight: 600, marginBottom: 4, fontFamily: 'var(--font-display)' }}>Demonstration Controls</div>
          <div style={{ fontSize: 13, color: 'var(--ink-soft)', marginBottom: 16 }}>
            Manually trigger fault conditions on the selected machine for a live presentation.
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10, marginBottom: 16 }}>
            {FAULTS.map(({ key, label, icon: Icon }) => (
              <button key={key} className="btn btn-outline btn-sm" style={{ justifyContent: 'flex-start' }}
                      onClick={() => triggerFault(key)}>
                <Icon size={14} /> {label}
              </button>
            ))}
          </div>

          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} onClick={restore}>
            <RotateCcw size={15} /> Restore Machine
          </button>

          {machine && (
            <div style={{ marginTop: 20, fontSize: 13, color: 'var(--ink-soft)', lineHeight: 1.8 }}>
              <div><strong>Status:</strong> {machine.status}</div>
              <div><strong>Water:</strong> {Math.round(machine.waterLevel)}% · <strong>Milk:</strong> {Math.round(machine.milkLevel)}% · <strong>Coffee:</strong> {Math.round(machine.coffeePowderLevel)}%</div>
              <div><strong>Temperature:</strong> {machine.temperature?.toFixed(1)}°C</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
