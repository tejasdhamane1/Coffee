import React, { useState } from 'react'
import { Plus } from 'lucide-react'
import MachineCard from '../components/MachineCard'
import LoadingState from '../components/LoadingState'
import Modal from '../components/Modal'
import usePolling from '../hooks/usePolling'
import { MachineAPI } from '../api/endpoints'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../components/Toast'

export default function Machines() {
  const { user } = useAuth()
  const toast = useToast()
  const { data: machines, loading, refresh } = usePolling(() => MachineAPI.getAll().then((r) => r.data), 10000)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ machineId: '', location: '', department: '' })
  const [filter, setFilter] = useState('ALL')

  const submit = async (e) => {
    e.preventDefault()
    try {
      await MachineAPI.create(form)
      toast.push('Machine added successfully.', 'success')
      setShowAdd(false)
      setForm({ machineId: '', location: '', department: '' })
      refresh()
    } catch (err) {
      toast.push(err.response?.data?.message || 'Failed to add machine.', 'error')
    }
  }

  if (loading) return <LoadingState label="Loading machines..." />

  const filtered = (machines || []).filter((m) => filter === 'ALL' || m.status === filter)

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Machine Network</h1>
          <div className="subtitle">{machines?.length || 0} machines across all offices.</div>
        </div>
        {user?.role === 'ADMIN' && (
          <button className="btn btn-primary" onClick={() => setShowAdd(true)}>
            <Plus size={16} /> Add Machine
          </button>
        )}
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {['ALL', 'ONLINE', 'OFFLINE', 'WARNING', 'MAINTENANCE'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className="btn btn-sm"
            style={{
              background: filter === s ? 'var(--espresso)' : 'var(--surface)',
              color: filter === s ? 'var(--cream)' : 'var(--ink)',
              border: '1px solid var(--border)'
            }}
          >
            {s.charAt(0) + s.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3">
        {filtered.map((m) => <MachineCard key={m.machineId} machine={m} />)}
      </div>

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add New Machine">
        <form onSubmit={submit}>
          <label className="label">Machine ID</label>
          <input className="input" style={{ marginBottom: 12 }} placeholder="CM007"
                 value={form.machineId} onChange={(e) => setForm({ ...form, machineId: e.target.value })} required />
          <label className="label">Location</label>
          <input className="input" style={{ marginBottom: 12 }} placeholder="Delhi Office"
                 value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} required />
          <label className="label">Department</label>
          <input className="input" style={{ marginBottom: 18 }} placeholder="Sales"
                 value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} required />
          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>Add Machine</button>
        </form>
      </Modal>
    </div>
  )
}
