-- Beans and Brews — reference schema
-- NOTE: The Spring Boot app auto-creates/updates these tables via Hibernate
-- (spring.jpa.hibernate.ddl-auto=update) and seeds demo data automatically
-- on first run (see DataSeeder.java). This file is provided for reference
-- and manual inspection only — you do not need to run it by hand.

CREATE DATABASE IF NOT EXISTS bean_brew;
USE bean_brew;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS vending_machines (
    machine_id VARCHAR(50) PRIMARY KEY,
    location VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL,
    temperature DOUBLE,
    water_level DOUBLE,
    milk_level DOUBLE,
    coffee_powder_level DOUBLE,
    last_seen DATETIME,
    offline_since DATETIME,
    total_downtime_minutes BIGINT,
    failure_count INT,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS consumption_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    machine_id VARCHAR(50) NOT NULL,
    coffee_type VARCHAR(30) NOT NULL,
    cups_dispensed INT NOT NULL,
    timestamp DATETIME NOT NULL,
    is_seed_data BOOLEAN DEFAULT FALSE,
    INDEX idx_machine_time (machine_id, timestamp),
    INDEX idx_timestamp (timestamp)
);

CREATE TABLE IF NOT EXISTS inventory_status (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    machine_id VARCHAR(50) NOT NULL,
    coffee_powder_level DOUBLE NOT NULL,
    milk_level DOUBLE NOT NULL,
    water_level DOUBLE NOT NULL,
    updated_at DATETIME,
    INDEX idx_machine (machine_id)
);

CREATE TABLE IF NOT EXISTS maintenance_alerts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    machine_id VARCHAR(50) NOT NULL,
    alert_type VARCHAR(40) NOT NULL,
    message VARCHAR(500),
    severity VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL,
    created_at DATETIME,
    resolved_at DATETIME,
    INDEX idx_machine_status (machine_id, status)
);

CREATE TABLE IF NOT EXISTS refill_predictions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    machine_id VARCHAR(50) NOT NULL,
    inventory_type VARCHAR(20) NOT NULL,
    remaining_inventory DOUBLE,
    average_daily_consumption DOUBLE,
    estimated_days_remaining DOUBLE,
    recommended_action VARCHAR(300),
    created_at DATETIME,
    INDEX idx_machine_type (machine_id, inventory_type)
);

-- Demo users (already seeded automatically by the backend on first boot):
--   admin@beansandbrews.com    / Admin@123    (ADMIN)
--   manager@beansandbrews.com  / Manager@123  (MANAGER)
--   operator@beansandbrews.com / Operator@123 (OPERATOR)
--
-- Demo machines (already seeded automatically):
--   CM001 Pune Office / Engineering
--   CM002 Pune Office / HR
--   CM003 Mumbai Office / Finance (seeded with a low-milk warning)
--   CM004 Bangalore Office / Engineering
--   CM005 Hyderabad Office / Management
--   CM006 Pune Office / Cafeteria
